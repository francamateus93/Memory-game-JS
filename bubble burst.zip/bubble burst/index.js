const numBubbles = 10;
const container = document.querySelector(".container")
let contador = 0;
for(let i=0; i<numBubbles; i++){

    let div = document.createElement("div");
    div.classList.add("bubble");

    let x = Math.floor(Math.random()*370)
    let y = Math.floor(Math.random()*370)

    div.style.top = y + "px";
    div.style.left = x + "px";
    container.appendChild(div);

}

container.addEventListener("click", pop);

function pop(event) {
    if(event.target.className === "bubble") {
        container.removeChild(event.target)
        contador++;
        if(contador === numBubbles) {
            alert("YA NO QUEDAN BURBUJAS")
        }
    }
}



